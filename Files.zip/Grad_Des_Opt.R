# Ayush Singh
# 19BEC1032
install.packages('calculus') # this package s used to find the differentiation of the function
install.packages('plot3D')   # this package is used to plot #d plots
install.packages("plot3Drgl")

library(calculus) # derivative functions
library(dplyr)
library("plot3Drgl")

fn=expression(2*x1^2 + 7*x1*x2 + 5*x2^2 - 2*x1 -  3*x2)

dfx = deriv(fn, c("x1","x2"))

SC <- 6       
alpha = 0.126 

fv = list()   
dvx1 = list() 
dvx2 = list() 
x1 = list()
x2 = list()

k = 1 

#initial Guess Value
x1 = 2
x2 = 1

fv <- as.numeric(eval(fn)) 

X1=list()
X2=list()

while (k <= 7){
  dv = eval(dfx)
  dvx1[k+1] = .grad[, "x1"]   # extract values with respect to x1 value
  dvx2[k+1] = .grad[, "x2"]   # extract values with respect to x2 value
  
  x1 = x1 - alpha*.grad[, "x1"] # x1 update equation / formula 
  x2 = x2 - alpha*.grad[, "x2"] # x2 update equation / formula
  
  X1[k+1]=x1
  X2[k+1]=x2
  
  fv[k+1]=eval(fn)
  SC <- abs(as.numeric(fv[k]) - as.numeric(fv[k+1])) # stopping criteria
  
  k=k+1
}


fv = unlist(fv)
fv
dvx1 = unlist(dvx1)
dvx1
dvx2 = unlist(dvx2)
dvx2
X1=unlist(X1)
X1
X2=unlist(X2)
X2


# plot the function
x1_data = seq(-5,5, by = 0.5)
x2_data = seq(-5,5, by = 0.5)

library(plot3D)
X =  mesh(x1_data, x2_data) 


x1 = X$x
x2 = X$y


(y = eval(fn))

surf3D(X$x, X$y,y, colvar = y, axes=TRUE, colkey = TRUE, theta = 60, phi = 15,  
       box = FALSE, main="3D Surf plot", xlab="X-value")

plotrgl()  # openGL --> grapns in another window  - Rotatable & Zoomable