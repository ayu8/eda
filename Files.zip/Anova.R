## AYUSH SINGH (19BEC1032)
## Expt 2

rm(list = ls())
setwd("E:/B. Tech/6th Sem/CSE3506 - EDA/Lab/Expt2")
df=read.csv("crop.data.csv")
df
summary(df)

#one-way Analysis
df$fertilizer=as.factor(df$fertilizer)
one_way=aov(yield~fertilizer,data=df)
one_way
summary(one_way)

#two-way Analysis
two_way=aov(yield~fertilizer+density,data=df)
summary(two_way)

#homogenity of variance
plot(one_way,1)

#normality test
plot(one_way,2)

#homogenity of variance
plot(two_way,1)

#normality test
plot(two_way,2)
