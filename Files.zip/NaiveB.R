rm(list = ls())
setwd("E:/B. Tech/6th Sem/CSE3506 - EDA/Lab/Expt5")
library(boot)
library(ggplot2)
library(psych)
library(dplyr)
data(melanoma)
head(melanoma)
melanoma$ulcer=as.factor(melanoma$ulcer)
melanoma$status=as.factor(melanoma$status)
pairs.panels(melanoma[-1])
melanoma %>% 
  ggplot(aes(x=ulcer,y=age,fill=ulcer)) + 
  geom_boxplot() + 
  ggtitle('Box plot based on age ')

melanoma %>%
  ggplot(aes(x=year,fill=ulcer))+
  geom_density(alpha=0.75,color='black')+
  ggtitle('Year-wise Density plot of ulcer cases ')

set.seed(234)
sample=sample(2,nrow(melanoma),replace=T,prob=c(0.8,0.2))
train=melanoma[sample==1, ]
test=melanoma[sample==2, ]
#install.packages("naivebayes")
library(naivebayes)

m1=naive_bayes(ulcer~ .,data=train)
m1
plot(m1)

p=predict(m1,train,type='prob')
#To find accuracy
p1=predict(m1,train)
(tab1=table(p1,train$ulcer))

1-sum(diag(tab1))/sum(tab1) #error probability
sum(diag(tab1))/sum(tab1)*100  #accuracy
