rm(list = ls())
setwd("E:/B. Tech/6th Sem/CSE3506 - EDA/Lab/Expt6")
library(ggplot2)
library(factoextra)
library(cluster)
?USArrests
df <- USArrests
is.na(df)
df <- na.omit(df)
head(df)
df <- scale(df)
head(df)
colnames(df)

?fviz_nbclust
fviz_nbclust(df, pam, method="wss")

set.seed(1)

km <- pam(df, 3, metric = "euclidean", stand = FALSE)
km
#plot results of final kmeans model
fviz_cluster(km, data = df)

df2<-data.frame(x=c(0,0,1,3,5,8,9,9),y=c(0,1,0,3,6,9,8,9))
(is.na(df2))

df2<-na.omit(df2)
head(df2)
df2<-scale(df2)
head(df2)
colnames(df2)

set.seed(1)
km<-pam(df2,3,metric="euclidean",stand=FALSE)
km

fviz_cluster(km,data=df2)
