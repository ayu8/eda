??gradDescent
install.packages("gradDescent")
install.packages("calculus")
install.packages("plot3D")
install.packages("plot3Drgl")
install.packages("caret")

library(gradDescent)
library(calculus)
library(dplyr)
library(caret)
library(plot3D)
library(plot3Drgl)

x=c(1,2,3,4,5,6,7,8,9,10)
y=c(10,12.8978,17.7586,23.3192,28.3129,32.135,35,40,45,48)

dataset<-data.frame(x,y)
set.seed(121)
trainIndex<-createDataPartition(dataset,p=.75,list=FALSE,times=1)
Train_data<-dataset[trainIndex,]
Test_data<-dataset[-trainIndex,]

plot(x,y,col="blue",pch=10)
alpha=0.1
maxItr=10
lst=list(alpha,maxItr)
model=gradDescentR.learn(dataset,featureScaling = FALSE, learningMethod = "GD", control = lst,seed = NULL)
y_pred=predict(model,dataset)
model

model=gradDescentR.learn(dataset,featureScaling = TRUE, scalingMethod = "VARIANCE",control = lst(alpha(0.01)), seed = NULL)
model=gradDescentR.learn(dataset)
model